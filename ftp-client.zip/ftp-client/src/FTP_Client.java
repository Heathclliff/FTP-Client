import org.apache.commons.net.ftp.FTPClient;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileInputStream;

public class FTP_Client {

    public static String[] GetList(String FTPADDR, String user, String Password,String Folder)
    {
        String[] RESULT;

        RESULT = null;

        FTPClient client = new FTPClient();
        try {
            client.connect(FTPADDR);
            client.login(user, Password);
            client.changeWorkingDirectory(Folder);
            RESULT = client.listNames();
            client.logout();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                client.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        return RESULT;
    }

    public static void UploadFileOnFtp(String FTPADDR, String user, String Password,String PathOnFtp, String FilenameOnLocalMachine)
    {
        FTPClient client = new FTPClient();

        FileInputStream fis = null;

        try {
            client.connect(FTPADDR);
            client.login(user, Password);

            String filename = FilenameOnLocalMachine;
            fis = new FileInputStream(filename);


            client.storeFile(PathOnFtp, fis);
            client.logout();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                client.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void DownloadFileFromFTP(String FTPADDR, String user, String Password,String FullPathToPutFile, String FilenameOnFTP)
    {

        FTPClient client = new FTPClient();
        FileOutputStream fos = null;

        try {
            client.connect(FTPADDR);
            client.login(user, Password);


//       The remote filename to be downloaded.

            String filename = FullPathToPutFile+FilenameOnFTP;
            fos = new FileOutputStream(filename);

            client.retrieveFile(FilenameOnFTP, fos);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
                client.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static void DeleteFileOnFtp(String FTPADDR, String user, String Password,String Filename)
    {
        FTPClient client = new FTPClient();
        try {
            client.connect(FTPADDR);
            client.login(user, Password);

            String filename = Filename;
            boolean deleted = client.deleteFile(filename);
            if (deleted) {
                System.out.println("File deleted...");
            }

            client.logout();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                client.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



    public static void main(String[] args) {

        DownloadFileFromFTP("127.0.0.1","FTPUser","qaz", "E:/","Myfile.txt");
        UploadFileOnFtp("127.0.0.1","FTPUser","qaz","1.txt","E:/1.txt");

        String[] RESULT = GetList("127.0.0.1","FTPUser","qaz","");
        for (int i=0;i<RESULT.length;i++)
        {
            System.out.println("Name = " + RESULT[i]);
        }

        DeleteFileOnFtp("127.0.0.1","FTPUser","qaz","file.txt");


    }
}
